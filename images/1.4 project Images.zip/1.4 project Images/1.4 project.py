#https://myanimelist.cdn-dena.com/images/characters/6/275276.jpg
#https://i.ytimg.com/vi/35H0Y93-0u8/maxresdefault.jpg
#http://tinyurl.com/hgqemwk
#http://tinyurl.com/h7dfsov

#ALL THE IMPORTS WMAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHA
import matplotlib.pyplot as plt
import os.path
import numpy as np
import PIL
import PIL.Image
import PIL.ImageDraw

#Open Suit cat's picture in numpy
directory = os.path.dirname(os.path.abspath(__file__))  
filepath_suitcat = os.path.join(directory, 'suitcat.jpg')
suit_cat_numpy = plt.imread(filepath_suitcat)

#Open dark saber in numpy
filepath_ds = os.path.join(directory, 'BlackSaber.jpg')
dark_saber_numpy = plt.imread(filepath_ds)

# Open Saber's picture in numpy.
filepath_saber = os.path.join(directory, 'Saber.jpg')
saber_numpy = plt.imread(filepath_saber)

# Opens the Hat in numpy.
filepath_hat = os.path.join(directory, 'tophat.jpg')
hat_numpy = plt.imread(filepath_hat)

# Converts Saber's, Dark Saber's, and Suit Cat's numpy picture to PIL
saber_image_pil = PIL.Image.fromarray(saber_numpy)
ds_image_pil = PIL.Image.fromarray(dark_saber_numpy)
suit_cat_image_pil = PIL.Image.fromarray(suit_cat_numpy)
hat_image_pil = PIL.Image.fromarray(hat_numpy)

'''# Cuts out all the extra stuff on Dark Saber's and Saber's picture.
ds_crop = ds_image_pil.crop( (5, 4, 84, 123) )
saber_crop = saber_image_pil.crop( (5, 4, 84, 123) )
'''

# Makes sure images of Dark Saber and Saber are small enough to paste on Jack's picture
ds_img_small = ds_image_pil.resize((140,200))
saber_img_small = saber_image_pil.resize((140,200))
hat_resize = hat_image_pil.resize((100,100))

# Places Dark Saber's and Saber's picture on either side of Jack
suit_cat_image_pil.paste(ds_img_small,(40,70))
suit_cat_image_pil.paste(saber_img_small,(420,70))

# Places a hat on Suit Cat.
suit_cat_image_pil.paste(hat_resize,(260,0))

suit_cat_numpy = np.array(suit_cat_image_pil)

# Makes the picture graysca
#gray_jack_pil = jack_image_pil.convert('LA')
'''
# Converts Jack's picture back to numpy.
#gray_jack_numpy = np.array(gray_jack_pil)
hat_resize = hat_resize.convert("RGBA")
hat_numpy = np.array(hat_resize)

# Makes hat background opaque
for r in range(50,100):
    for c in range(50,100):
        if sum(hat_numpy[r][c])>730:
            hat_numpy[r][c] = [225,0,0,50]
for r in range(50,100):
    for c in range(50,100):
        if sum(hat_numpy[r][c])>730:
            hat_numpy[r][c] = [0,0,0,0]
'''
fig, ax = plt.subplots(1, 1)
ax.imshow(suit_cat_numpy, interpolation='none')
fig.show()